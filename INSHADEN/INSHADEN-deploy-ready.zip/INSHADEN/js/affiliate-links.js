/*
 * INSHADEN affiliate link settings
 * Add only the exact HTTPS affiliate URL issued to INSHADEN by the program.
 * Leave a value empty until the account is approved and the tracked link is provided.
 * The website automatically shows an INSHADEN WhatsApp inquiry button when a link is empty.
 * Do not remove or edit tracking parameters supplied by the affiliate network.
 */
window.AFF = {
  cell: "",
  daynight: "",
  zebra: "",
  roman: "",
  roller: "",
  sheer: ""
};
