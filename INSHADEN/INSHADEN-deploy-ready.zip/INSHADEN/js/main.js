const IMG={
 "cell": "assets/img/cell.jpg",
 "daynight": "assets/img/daynight.jpg",
 "zebra": "assets/img/zebra.jpg",
 "roman": "assets/img/roman.jpg",
 "roller": "assets/img/roller.jpg",
 "sheer": "assets/img/sheer.jpg",
 "tour": "assets/img/tour.jpg",
 "c0": "assets/img/c0.jpg",
 "c1": "assets/img/c1.jpg",
 "c2": "assets/img/c2.jpg",
 "c3": "assets/img/c3.jpg",
 "c4": "assets/img/c4.jpg",
 "c5": "assets/img/c5.jpg"
};

const P=[["cell","Cellular shades","Pleated honeycomb look","Clean, pleated cells in a slim profile. Top-down/bottom-up styles let you open from either end.",""],
["daynight","Day & night cellular","Sheer + blackout","A soft sheer layer for daylight and a solid layer for sleep, together in one shade.",""],
["zebra","Zebra shades","Alternating sheer & solid bands","Line the bands up for a clear view, offset them for soft filtered light or privacy.",""],
["roman","Woven & Roman shades","Natural texture, soft folds","Textured woven fabric that stacks into gentle pleats as it rises.",""],
["roller","Roller shades","Flat fabric, slim headrail","A simple, modern look that rolls up neatly out of the way.",""],
["sheer","Sheer shades","Diffused daylight","A soft, airy look that gently filters sunlight while keeping a view.",""]];
const $=s=>document.querySelector(s);
const contactUrl=name=>`https://wa.me/50672405908?text=${encodeURIComponent(`Hello INSHADEN, I would like to know more about ${name}.`)}`;
const safeAffiliateUrl=value=>{try{const u=new URL(value);return u.protocol==="https:"?u.href:""}catch{return ""}};
$("#prods").innerHTML=P.map(p=>{const href=safeAffiliateUrl(window.AFF?.[p[0]]||"");return `<article class="card" id="product-${p[0]}"><img src="${IMG[p[0]]}" alt="${p[1]} in a living space" loading="lazy"><div class="cb"><span class="tag">${p[2]}</span><h3>${p[1]}</h3><p>${p[3]}</p>${href?`<a class="btn p" href="${href}" target="_blank" rel="sponsored noopener noreferrer">Explore product</a>`:`<a class="btn p" href="${contactUrl(p[1])}" target="_blank" rel="noopener noreferrer">Ask us about this product</a>`}</div></article>`}).join("");
const menuToggle=$("#menuToggle"),mainNav=$("#mainNav");
if(menuToggle&&mainNav){menuToggle.addEventListener("click",()=>{const open=menuToggle.getAttribute("aria-expanded")!=="true";menuToggle.setAttribute("aria-expanded",String(open));menuToggle.setAttribute("aria-label",open?"Close navigation":"Open navigation");mainNav.classList.toggle("open",open)});mainNav.addEventListener("click",e=>{if(e.target.closest("a")){menuToggle.setAttribute("aria-expanded","false");menuToggle.setAttribute("aria-label","Open navigation");mainNav.classList.remove("open")}})}
$("#soon").innerHTML=`<article class="card soon"><div class="cb"><span class="tag">Explore by request</span><h3>Vertical blinds</h3><p>Looking for a vertical solution? Ask INSHADEN and we can help you explore options.</p><a class="btn p" href="${contactUrl("vertical blinds")}" target="_blank" rel="noopener noreferrer">Ask about vertical blinds</a></div></article>`+[["Motorized curtains & tracks","Moves sideways"],["Smart hubs & remotes","Control"],["Accessories & samples","Finishing touches"]].map(c=>`<article class="card soon"><div class="cb"><span class="tag">${c[1]}</span><h3>${c[0]}</h3><p>Coming soon.</p></div></article>`).join("");
const C=[["White","#e5e5e5"],["Cream","#d5cab3"],["Gray","#c1c1c1"],["Brown","#927c78"],["Black","#2c2c2c"],["Rosy Brown","#c095a6"]];
$("#sw").innerHTML=C.map((c,i)=>`<button style="background:${c[1]}" aria-label="${c[0]}" aria-pressed="${i==1}" data-i="${i}"></button>`).join("");
function pick(i){$("#cimg").src=IMG["c"+i];$("#cn").textContent="Selected: "+C[i][0];document.querySelectorAll("#sw button").forEach((b,j)=>b.setAttribute("aria-pressed",j==i))}
$("#sw").onclick=e=>{const b=e.target.closest("button");if(b)pick(+b.dataset.i)};pick(1);$("#timg").src=IMG.tour;
const v=$("#v");
let tg=0,cur=0;function prog(){const h=$("#hero"),r=h.getBoundingClientRect();return Math.min(1,Math.max(0,-r.top/(h.offsetHeight-innerHeight)))}
function tick(){const p=prog();tg=p;if(v.duration){cur+=(tg-cur)*.18;if(Math.abs(tg-cur)<.0005)cur=tg;v.currentTime=cur*(v.duration-.05)}$("#pb").style.width=(p*100)+"%";$("#cp").style.opacity=Math.max(0,1-p*3.2);$("#hd").classList.toggle("s",scrollY>innerHeight*3);requestAnimationFrame(tick)}

const MV={voice:"assets/video/voice.mp4",woven:"assets/video/woven.mp4",sky:"assets/video/sky.mp4",dark:"assets/video/dark.mp4"},MI={gable:"assets/img/gable.jpg",roof:"assets/img/roof.jpg"};
$("#vids").innerHTML=[["voice","Smart control, your way","Remote and voice-assistant control, as shown in a supplier demo."],["woven","Woven & Roman shades","Natural textures, fabric samples and remote control."],["sky","Skylight shades","A shade that follows the slope of a roof window."],["dark","Blackout in action","A room going dark as the shade closes."]].map(d=>`<figure class="vid"><video data-s="${MV[d[0]]}" muted loop playsinline preload="none" aria-label="${d[1]}"></video><figcaption><b>${d[1]}</b><span>${d[2]}</span></figcaption></figure>`).join("");
$("#shp").innerHTML=[["gable","Gable & triangle windows","Cellular shades can be made to follow angled and sloped windows. Availability depends on the supplier, so check each listing.","Cellular shades fitted to triangular and sloped windows"],["roof","Skylights & glass roofs","Shades can run overhead beneath a glass roof or skylight. Check the supplier for compatible products.","Cellular shades under an overhead glass roof"]].map(d=>`<article class="card shp"><img src="${MI[d[0]]}" alt="${d[3]}" loading="lazy"><div class="cb"><span class="tag">Special shapes</span><h3>${d[1]}</h3><p>${d[2]}</p></div></article>`).join("");
const rm=matchMedia("(prefers-reduced-motion: reduce)").matches,io=new IntersectionObserver(es=>es.forEach(e=>{const m=e.target;if(e.isIntersecting){if(!m.src)m.src=m.dataset.s;if(!rm)m.play().catch(()=>{})}else m.pause()}),{threshold:.35});
document.querySelectorAll(".vid video").forEach(m=>{if(rm)m.controls=true;io.observe(m)});
v.addEventListener("loadedmetadata",()=>{v.pause();tick()});tick();
