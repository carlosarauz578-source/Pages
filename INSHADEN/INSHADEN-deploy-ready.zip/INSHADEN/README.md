# INSHADEN website

Static website for GitHub Pages. No build step or backend is required.

## Publish

Publish the contents of this `site/` directory as the website root, or copy its contents into the repository's configured Pages root. Keep the `assets/`, `css/`, `js/` and `window-tour/` directories together. The interactive tour is included locally at `window-tour/index.html`; the homepage does not depend on a private Claude artifact URL.

## Contact details

- Email: `support.inshaden@gmail.com`
- WhatsApp: `https://wa.me/50672405908`
- Domain: `https://inshaden.com/`

## Affiliate links

Edit `js/affiliate-links.js`. Add the exact HTTPS tracking URL issued to INSHADEN for the matching product key (`cell`, `daynight`, `zebra`, `roman`, `roller`, or `sheer`). Keep the supplied query parameters intact. Leave values empty until an affiliate program has approved the account and provided the URL. Empty or invalid links automatically fall back to an INSHADEN WhatsApp inquiry button; no checkout or third-party destination is fabricated.

## Before commercial launch

Confirm written permission or approved affiliate media rights for supplier images and videos in `assets/`. The presence of media in this project does not establish permission to publish it commercially. Verify the site and interactive tour on desktop and mobile browsers after deployment.
