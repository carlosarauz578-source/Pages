# CODELINGUA — primera versión funcional

Sitio web estático preparado para GitHub Pages.

## Abrir localmente
1. Descarga y descomprime `CODELINGUA.zip`.
2. Abre `index.html` en un navegador moderno.
3. No requiere instalación ni dependencias de Node.js.

## Publicar en GitHub Pages
1. Crea un repositorio llamado `codelingua` (o utiliza uno existente).
2. Sube `index.html`, `styles.css`, `app.js` y este README a la raíz.
3. En GitHub entra a **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`, guarda.
6. Espera la publicación y abre la URL que GitHub Pages indique.

## Funciones incluidas
- Navegación entre panel, lenguajes, ruta, tutor, laboratorio y progreso.
- Catálogo de 13 lenguajes/tecnologías: Python, Bash, HTML, JavaScript, TypeScript, SQL, PowerShell, Go, Rust, Solidity, C, C++ y Assembly.
- Cinco etapas de dominio por competencias.
- Tutor local de demostración (no conectado a un modelo de IA).
- Editor de texto de código y análisis estructural básico (no ejecuta código).
- Guardado del progreso en `localStorage` del navegador.

## Limitaciones conocidas de esta versión
- No existe todavía autenticación ni sincronización entre dispositivos.
- El tutor no llama a una API de IA.
- El laboratorio no compila ni ejecuta código.
- Los porcentajes son indicadores iniciales de actividad, no certificaciones de dominio.
- AI-Script no aparece como lenguaje independiente: se mantiene como concepto transversal pendiente de una definición técnica precisa.

## Próximas fases recomendadas
1. Definir el currículo y ejercicios por lenguaje en archivos JSON.
2. Incorporar pruebas adaptativas y evaluación de comprensión.
3. Conectar un backend seguro para el tutor IA (nunca exponer claves API en JavaScript público).
4. Integrar ejecución aislada de código por lenguaje.
5. Añadir perfiles, sincronización y analítica de aprendizaje.
